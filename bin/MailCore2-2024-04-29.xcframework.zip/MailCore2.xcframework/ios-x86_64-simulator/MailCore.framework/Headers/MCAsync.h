//
//  MCAsync.h
//  mailcore2
//
//  Created by DINH Viêt Hoà on 1/11/13.
//  Copyright (c) 2013 MailCore. All rights reserved.
//

#ifndef MAILCORE_MCASYNC_H

#define MAILCORE_MCASYNC_H

#include <MailCore/MCAsyncSMTP.h>
#include <MailCore/MCAsyncIMAP.h>
#include <MailCore/MCAsyncPOP.h>
#include <MailCore/MCAsyncNNTP.h>

#endif
